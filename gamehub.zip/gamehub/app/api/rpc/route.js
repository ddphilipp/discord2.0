import { NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { sql } from '../../../lib/db';
import { setSession, getUser, clearSession } from '../../../lib/auth';

const ok = (d = {}) => NextResponse.json(d);
const err = (m, s = 400) => NextResponse.json({ error: m }, { status: s });
const name = (s) => String(s || '').trim().toLowerCase();

async function allowed(uid, scope, ref) {
  if (scope === 'dm') {
    return (await sql`select 1 from friendships where id=${ref} and status='accepted' and (a=${uid} or b=${uid})`).length > 0;
  }
  if (scope === 'ch') {
    return (await sql`select 1 from channels c join room_members m on m.room_id=c.room_id where c.id=${ref} and m.user_id=${uid}`).length > 0;
  }
  return false;
}
const isOwner = async (uid, rid) => (await sql`select 1 from rooms where id=${rid} and owner=${uid}`).length > 0;
const isMember = async (uid, rid) => (await sql`select 1 from room_members where room_id=${rid} and user_id=${uid}`).length > 0;

export async function POST(req) {
  const q = await req.json();
  const a = q.action;
  try {
    if (a === 'register' || a === 'login') {
      const u = name(q.username), p = String(q.password || '');
      if (!/^[a-z0-9_]{3,20}$/.test(u)) return err('Username: 3–20 Zeichen, nur a–z, 0–9 und _');
      if (p.length < 6) return err('Das Passwort braucht mindestens 6 Zeichen');
      if (a === 'register') {
        if ((await sql`select 1 from users where username=${u}`).length) return err('Dieser Username ist schon vergeben');
        const r = await sql`insert into users(username,pw) values(${u},${await bcrypt.hash(p, 10)}) returning id`;
        await setSession(r[0].id);
      } else {
        const r = await sql`select id,pw from users where username=${u}`;
        if (!r.length || !(await bcrypt.compare(p, r[0].pw))) return err('Username oder Passwort ist falsch');
        await setSession(r[0].id);
      }
      return ok();
    }
    if (a === 'logout') { clearSession(); return ok(); }

    const me = await getUser();
    if (!me) return err('Nicht eingeloggt', 401);

    switch (a) {
      case 'state': {
        const [u] = await sql`select username from users where id=${me}`;
        if (!u) return err('Nicht eingeloggt', 401);
        const friends = await sql`select f.id, f.status, (f.a=${me}) as mine, o.username from friendships f join users o on o.id = (case when f.a=${me} then f.b else f.a end) where f.a=${me} or f.b=${me} order by o.username`;
        const rooms = await sql`select r.id, r.name, r.owner from rooms r join room_members m on m.room_id=r.id where m.user_id=${me} order by r.name`;
        const channels = await sql`select c.id, c.room_id, c.name, c.kind from channels c join room_members m on m.room_id=c.room_id where m.user_id=${me} order by c.id`;
        const reqs = await sql`select q.room_id, q.user_id, u.username, r.name as room from room_requests q join rooms r on r.id=q.room_id join users u on u.id=q.user_id where r.owner=${me}`;
        return ok({ me: u.username, myId: me, friends, rooms, channels, reqs });
      }
      case 'friend_add': {
        const t = await sql`select id from users where username=${name(q.username)}`;
        if (!t.length) return err('Diesen User gibt es nicht');
        if (t[0].id === me) return err('Das bist du selbst');
        const ex = await sql`select 1 from friendships where (a=${me} and b=${t[0].id}) or (a=${t[0].id} and b=${me})`;
        if (ex.length) return err('Ihr seid schon befreundet oder es ist eine Anfrage offen');
        await sql`insert into friendships(a,b) values(${me},${t[0].id})`;
        return ok();
      }
      case 'friend_answer': {
        if (q.accept) await sql`update friendships set status='accepted' where id=${q.id} and b=${me}`;
        else await sql`delete from friendships where id=${q.id} and (a=${me} or b=${me})`;
        return ok();
      }
      case 'room_create': {
        const n = String(q.name || '').trim().slice(0, 40);
        if (!n) return err('Der Room braucht einen Namen');
        const r = await sql`insert into rooms(name,owner) values(${n},${me}) returning id`;
        await sql`insert into room_members(room_id,user_id) values(${r[0].id},${me})`;
        await sql`insert into channels(room_id,name,kind) values(${r[0].id},'allgemein','text'),(${r[0].id},'Lounge','voice')`;
        return ok();
      }
      case 'room_search': {
        const rows = await sql`select r.id, r.name, (select count(*) from room_members where room_id=r.id)::int as n, exists(select 1 from room_members where room_id=r.id and user_id=${me}) as member from rooms r where r.name ilike ${'%' + String(q.q || '').trim() + '%'} order by r.name limit 20`;
        return ok({ rows });
      }
      case 'room_request': {
        if (await isMember(me, q.room_id)) return err('Du bist schon in diesem Room');
        await sql`insert into room_requests(room_id,user_id) values(${q.room_id},${me}) on conflict do nothing`;
        return ok();
      }
      case 'room_answer': {
        if (!(await isOwner(me, q.room_id))) return err('Nur der Besitzer kann Anfragen beantworten', 403);
        if (q.accept) await sql`insert into room_members(room_id,user_id) values(${q.room_id},${q.user_id}) on conflict do nothing`;
        await sql`delete from room_requests where room_id=${q.room_id} and user_id=${q.user_id}`;
        return ok();
      }
      case 'room_add': {
        if (!(await isMember(me, q.room_id))) return err('Kein Zugriff', 403);
        const t = await sql`select id from users where username=${name(q.username)}`;
        if (!t.length) return err('Diesen User gibt es nicht');
        await sql`insert into room_members(room_id,user_id) values(${q.room_id},${t[0].id}) on conflict do nothing`;
        await sql`delete from room_requests where room_id=${q.room_id} and user_id=${t[0].id}`;
        return ok();
      }
      case 'channel_create': {
        if (!(await isOwner(me, q.room_id))) return err('Nur der Besitzer kann Channels erstellen', 403);
        const n = String(q.name || '').trim().slice(0, 40);
        if (!n) return err('Der Channel braucht einen Namen');
        await sql`insert into channels(room_id,name,kind) values(${q.room_id},${n},${q.kind === 'voice' ? 'voice' : 'text'})`;
        return ok();
      }
      case 'msgs': {
        if (!(await allowed(me, q.scope, q.ref))) return err('Kein Zugriff', 403);
        const m = await sql`select * from (select m.id, m.body, m.file_url, m.file_name, m.created_at, u.username from messages m join users u on u.id=m.user_id where m.scope=${q.scope} and m.ref=${q.ref} order by m.id desc limit 100) x order by id`;
        const g = await sql`select game, note, links from chat_game where scope=${q.scope} and ref=${q.ref}`;
        return ok({ m, game: g[0] || null });
      }
      case 'send': {
        if (!(await allowed(me, q.scope, q.ref))) return err('Kein Zugriff', 403);
        const body = String(q.body || '').slice(0, 4000);
        if (!body.trim() && !q.file_url) return ok();
        await sql`insert into messages(scope,ref,user_id,body,file_url,file_name) values(${q.scope},${q.ref},${me},${body},${q.file_url || null},${q.file_name || null})`;
        return ok();
      }
      case 'game_set': {
        if (!(await allowed(me, q.scope, q.ref))) return err('Kein Zugriff', 403);
        await sql`insert into chat_game(scope,ref,game,note,links) values(${q.scope},${q.ref},${String(q.game || '').slice(0, 80)},${String(q.note || '').slice(0, 1000)},${String(q.links || '').slice(0, 1000)}) on conflict(scope,ref) do update set game=excluded.game, note=excluded.note, links=excluded.links`;
        return ok();
      }
    }
    return err('Unbekannte Aktion');
  } catch (e) {
    console.error(e);
    return err('Serverfehler', 500);
  }
}
