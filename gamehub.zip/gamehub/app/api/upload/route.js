import { NextResponse } from 'next/server';
import { put } from '@vercel/blob';
import { getUser } from '../../../lib/auth';

export async function POST(req) {
  if (!(await getUser())) return NextResponse.json({ error: 'Nicht eingeloggt' }, { status: 401 });
  const f = (await req.formData()).get('file');
  if (!f || f.size > 4 * 1024 * 1024) return NextResponse.json({ error: 'Datei fehlt oder ist größer als 4 MB' }, { status: 400 });
  const b = await put(`uploads/${Date.now()}-${f.name}`, f, { access: 'public' });
  return NextResponse.json({ url: b.url, name: f.name });
}
